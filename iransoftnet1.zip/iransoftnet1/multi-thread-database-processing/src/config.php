<?php
return [

    "token"=>"sad5sadASDIw1dnIWD9jwi_wjd_wO[qm6vpsMMMMdj777mk2wa8oq7i4eyr",
    "baseUrl"=>env("APP_URL")
];